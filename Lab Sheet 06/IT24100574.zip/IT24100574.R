# Exercise 1

# Set working directory
setwd("C:/Users/Behraad Aswer/Desktop/IT24100574")

# Parameters for binomial distribution
n <- 50  # Number of students
p <- 0.85  # Probability of passing

# Probability distribution for binomial
binom_dist <- dbinom(0:n, size = n, prob = p)

# Probability that at least 47 students passed
prob_at_least_47 <- sum(binom_dist[48:51])  # P(X >= 47)
prob_at_least_47


# Exercise 2

# Parameters for Poisson distribution
lambda <- 12  # Average calls per hour

# Probability that exactly 15 calls are received
prob_15_calls <- dpois(15, lambda = lambda)
prob_15_calls
