# Set the working directory (change the path to match your folder)
setwd("C:\\Users\\Behraad Aswer\\Desktop\\ps labs")

# Step 1: Generate a random sample of size 25 for the baking time.
set.seed(123)  # For reproducibility
baking_time <- rnorm(25, mean = 45, sd = 2)

# Step 2: Test whether the average baking time is less than 46 minutes at 5% level of significance.
t_test_result <- t.test(baking_time, mu = 46, alternative = "less")

# Display the test result
print(t_test_result)

# Extract specific components if needed
t_test_result$statistic     # Test statistic
t_test_result$p.value       # P-value
t_test_result$conf.int      # Confidence interval
